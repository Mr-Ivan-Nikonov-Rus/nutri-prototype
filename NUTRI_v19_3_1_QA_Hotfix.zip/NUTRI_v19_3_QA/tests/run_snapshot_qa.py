"""Actual Chromium UI checks on the unchanged NUTRI v19.3 HTML snapshot.

This environment blocks browser HTTP/file/data navigation. The real HTML is loaded
with page.set_content, with isolated in-memory localStorage to support data flows.
"""
from __future__ import annotations
import json
import traceback
from datetime import date, timedelta
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'index.html').read_text(encoding='utf-8')
RESULTS = []
BROWSER = None

STORAGE_JS = '''(initial) => {
  const db = new Map(Object.entries(initial || {}));
  Object.defineProperty(window, 'localStorage', {
    configurable: true,
    value: {
      setItem(k,v){ db.set(String(k), String(v)); },
      getItem(k){ return db.has(String(k)) ? db.get(String(k)) : null; },
      removeItem(k){ db.delete(String(k)); },
      clear(){ db.clear(); },
      key(i){ return [...db.keys()][i] ?? null; },
      get length(){ return db.size; },
      _dump(){return Object.fromEntries(db)}
    }
  });
}'''

def open_app(mobile=False, storage=None):
    page = BROWSER.new_page(viewport={ 'width': 390 if mobile else 1280, 'height': 844 if mobile else 900}, device_scale_factor=2 if mobile else 1)
    errors = []
    page.on('pageerror', lambda e: errors.append(str(e)))
    page.evaluate(STORAGE_JS, storage or {})
    page.set_content(HTML, wait_until='load', timeout=20000)
    assert page.evaluate('window.NUTRI_QA.appVersion') == '19.3.1'
    assert not errors, 'JavaScript exception on initial load: '+repr(errors)
    return page

def state(page):
    return page.evaluate('window.NUTRI_QA.getState()')

def go_tab(page, route):
    page.locator(f'[data-act="tab"][data-route="{route}"]').click()
    assert page.evaluate('window.NUTRI_QA.getRoute()') == route

def current_day(page):
    return page.evaluate("() => {const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')}")

def earlier(page, amount=3):
    return (date.fromisoformat(current_day(page))-timedelta(days=amount)).isoformat()

def catalog_add(page, d, status='consumed'):
    go_tab(page, 'nutrition')
    page.locator('[data-change="diaryDate"]').fill(d)
    page.locator('[data-act="catalog"]').first.click()
    page.locator('[data-act="catalogType"][data-val="products"]').click()
    count=page.locator('.catalog-card[data-type="product"]').count()
    assert count>0
    page.locator('.catalog-card[data-type="product"]').first.click()
    page.locator('#previewMeal').select_option('breakfast')
    page.locator('#previewEntryDate').fill(d)
    page.locator(f'[data-act="savePreview"][data-status="{status}"]').click()

def test_launch_navigation():
    page=open_app(mobile=True)
    try:
        assert state(page)['entries']==[]
        assert state(page)['supplements']==[]
        assert page.locator('[data-act="tab"]').count()==3
        assert 'Ошибка интерфейса' not in page.locator('#main').inner_text()
        for route in ['nutrition','progress','today']:
            go_tab(page,route)
    finally:page.close()

def test_numerical_engine():
    page=open_app()
    try:
        result=page.evaluate('''() => {const q=window.NUTRI_QA,t=q.nutriBalanceSelfTests();return {dims:q.DB.dims.length,total:q.DB.dims.reduce((s,x)=>s+x.weight,0),passed:t.passed,n:t.total}}''')
        assert result['dims']==22
        assert abs(result['total']-1)<1e-10
        assert result['passed']==result['n'] and result['n']>0,repr(result)
    finally:page.close()

def test_date_picker_and_future():
    page=open_app(mobile=True)
    try:
        dates=page.evaluate('''() => {let v=window.NUTRI_QA.validDiaryDate;return {leap:v('2024-02-29'),invalid:v('2024-02-30'),tooOld:v('1899-12-31'),min:v('1900-01-01')}}''')
        assert dates=={'leap':True,'invalid':False,'tooOld':False,'min':True}
        yesterday=earlier(page,1)
        page.locator('[data-change="overviewDate"]').fill(yesterday)
        assert page.evaluate('window.NUTRI_QA.getDate()')==yesterday
        go_tab(page,'nutrition')
        assert page.locator('[data-change="diaryDate"]').input_value()==yesterday
        go_tab(page,'progress')
        assert page.locator('[data-change="progressEndDate"]').input_value()==yesterday
    finally:page.close()

def test_catalog_save_retro_persistence():
    page=open_app()
    try:
        d=earlier(page,3)
        catalog_add(page,d)
        s=state(page)
        assert len(s['entries'])==1
        assert s['entries'][0]['date']==d and s['entries'][0]['status']=='consumed'
        assert s['entries'][0]['meal']=='breakfast'
        kcal=page.evaluate('(d)=>window.NUTRI_QA.sumDay(d).kcal',d)
        assert kcal>0
        dump=page.evaluate('localStorage._dump()')
    finally:page.close()
    page=open_app(storage=dump)
    try:
        assert len(state(page)['entries'])==1
        obs=page.evaluate('([d])=>window.NUTRI_QA.progressObservation("kcal",d)',[d])
        assert abs(obs['v']-kcal)<0.01
        go_tab(page,'progress')
        page.locator('[data-change="progressEndDate"]').fill(d)
        assert 'Ошибка интерфейса' not in page.locator('#main').inner_text()
    finally:page.close()

def test_future_planned_not_consumed():
    page=open_app()
    try:
        future=(date.fromisoformat(current_day(page))+timedelta(days=3)).isoformat()
        go_tab(page,'nutrition')
        page.locator('[data-act="catalog"]').first.click()
        page.locator('[data-act="catalogType"][data-val="products"]').click()
        page.locator('.catalog-card[data-type="product"]').first.click()
        page.locator('#previewEntryDate').fill(future)
        page.locator('[data-act="savePreview"][data-status="consumed"]').click()
        assert len(state(page)['entries'])==0
        page.locator('[data-act="savePreview"][data-status="planned"]').click()
        s=state(page)
        assert len(s['entries'])==1 and s['entries'][0]['status']=='planned' and s['entries'][0]['date']==future
        assert page.evaluate('(d)=>window.NUTRI_QA.sumDay(d).kcal',future)==0
    finally:page.close()

def test_planned_does_not_count():
    page=open_app()
    try:
        d=earlier(page,2)
        catalog_add(page,d,'planned')
        assert len(state(page)['entries'])==1
        assert page.evaluate('(d)=>window.NUTRI_QA.sumDay(d).kcal',d)==0
        obs=page.evaluate('(d)=>window.NUTRI_QA.progressObservation("kcal",d)',d)
        assert obs['v'] is None
    finally:page.close()

def test_delete_undo():
    page=open_app()
    try:
        d=earlier(page,2)
        catalog_add(page,d)
        item=state(page)['entries'][0]
        page.locator('[data-act="meal"][data-meal="breakfast"]').click()
        page.locator(f'[data-act="deleteEntry"][data-id="{item["id"]}"]').click()
        assert state(page)['entries']==[]
        page.locator('[data-act="undoDelete"]').click()
        assert state(page)['entries'][0]['id']==item['id']
    finally:page.close()

def test_manual_recipe_edit():
    page=open_app()
    try:
        d=earlier(page,4)
        go_tab(page,'nutrition')
        page.locator('[data-act="addMeal"]').first.click()
        page.locator('#manualEntryDate').fill(d)
        page.locator('#manualName').fill('QA рецепт')
        name=page.evaluate('window.NUTRI_QA.DB.ingredients.find(x=>x.name.length>3).name')
        page.locator('[data-manual="search"][data-index="0"]').fill(name)
        assert page.locator('.ingredient-choice').count()>0
        page.locator('.ingredient-choice').first.click()
        page.locator('[data-manual="grams"][data-index="0"]').fill('150')
        page.locator('input[data-manual="saveRecipe"]').check()
        page.locator('#manualMealForm button[type="submit"]').click()
        s=state(page)
        assert len(s['entries'])==1 and len(s['userRecipes'])==1
        assert s['entries'][0]['date']==d and s['entries'][0]['items'][0]['g']==150
        item=s['entries'][0]
        page.locator('[data-act="meal"][data-meal="lunch"]').click()
        page.locator(f'[data-act="editEntry"][data-id="{item["id"]}"]').click()
        page.locator('[data-manual="grams"][data-index="0"]').fill('180')
        page.locator('#manualMealForm button[type="submit"]').click()
        assert len(state(page)['entries'])==1
        assert state(page)['entries'][0]['items'][0]['g']==180
    finally:page.close()

def test_historical_norms():
    page=open_app()
    try:
        s=state(page)
        old=dict(s['goals']);old['kcal']=1700
        s['goalHistory']=[{'date':'2026-01-01','at':'2026-01-01T09:00:00.000Z','next':old,'previous':old,'reason':'QA fixture'}]
        page.evaluate('s=>localStorage.setItem("NUTRI_PERSONAL_V1",JSON.stringify(s))',s)
        dump=page.evaluate('localStorage._dump()')
    finally:page.close()
    page=open_app(storage=dump)
    try:
        d='2026-02-01'
        assert page.evaluate('d=>window.NUTRI_QA.goalsForDate(d).kcal',d)==2000
        go_tab(page,'progress')
        page.locator('[data-change="normTimeline"]').select_option('historical')
        assert page.evaluate('d=>window.NUTRI_QA.goalsForDate(d).kcal',d)==1700
        page.locator('[data-change="normTimeline"]').select_option('current')
        assert page.evaluate('d=>window.NUTRI_QA.goalsForDate(d).kcal',d)==2000
    finally:page.close()

def test_progress_periods_missing():
    page=open_app(mobile=True)
    try:
        go_tab(page,'progress')
        for period in [7,28,90,0]:
            page.locator(f'[data-act="period"][data-num="{period}"]').click()
            assert page.locator('.progress-plot').count()==1
        d=earlier(page,20)
        obs=page.evaluate('d=>window.NUTRI_QA.progressObservation("kcal",d)',d)
        assert obs['v'] is None
    finally:page.close()

def test_supplements():
    page=open_app()
    try:
        go_tab(page,'nutrition')
        page.locator('[data-act="supplementForm"]').first.click()
        page.locator('#suppForm [name="name"]').fill('QA D3')
        page.locator('#suppForm [name="amount"]').fill('10')
        page.locator('#suppForm [name="nutrient"]').select_option('vitamin_d_mcg')
        page.locator('#suppForm [name="nutrientAmount"]').fill('10')
        page.locator('#suppForm [name="status"]').select_option('planned')
        page.locator('#suppForm button[type="submit"]').click()
        assert state(page)['supplements'][0]['status']=='planned'
        go_tab(page,'nutrition')
        page.locator('[data-act="toggleSupp"]').first.click()
        assert state(page)['supplements'][0]['status']=='taken'
    finally:page.close()

def test_export_json():
    page=open_app()
    try:
        d=earlier(page,3)
        catalog_add(page,d)
        page.locator('[data-act="profile"]').click()
        page.locator('[data-act="settings"]').click()
        page.locator('[data-act="privacy"]').click()
        page.locator('[data-act="export"]').click()
        data=json.loads(page.locator('#backupTextArea').input_value())
        assert data['schemaVersion']==1 and len(data['entries'])==1 and data['entries'][0]['date']==d
    finally:page.close()

def test_segments_and_layout():
    page=open_app(mobile=True)
    try:
        assert page.locator('[data-act="segment"]').count()==3
        for segment, text in [('vitamins','Витамин D'),('minerals','Магний'),('macros','Насыщенные')]:
            page.locator(f'[data-act="segment"][data-val="{segment}"]').click()
            assert text in page.locator('#main').inner_text()
        dims=page.evaluate('''() => ({outer:document.documentElement.scrollWidth,viewport:document.documentElement.clientWidth,phone:document.querySelector('#phone').getBoundingClientRect().width})''')
        assert dims['outer']<=dims['viewport']+1 and dims['phone']<=dims['viewport']+1,repr(dims)
    finally:page.close()

def test_legacy_goalhistory_compatibility():
    """Regression probe for an import without optional historical goal snapshots."""
    page=open_app()
    try:
        s=state(page)
        del s['goalHistory']
        page.evaluate('s=>localStorage.setItem("NUTRI_PERSONAL_V1",JSON.stringify(s))',s)
        dump=page.evaluate('localStorage._dump()')
    finally:page.close()
    page=open_app(storage=dump)
    try:
        page.locator('[data-act="profile"]').click()
        page.locator('[data-act="plan"]').click()
        page.locator('#goalForm button[type="submit"]').click()
        assert 'История изменений' not in page.locator('#toast').inner_text()  # availability check
        assert isinstance(state(page).get('goalHistory'),list), 'Imported v1 state is missing goalHistory after goals save'
    finally:page.close()

def test_text_backup_import_legacy():
    page=open_app()
    try:
        snapshot=state(page)
        del snapshot['goalHistory']
        page.locator('[data-act="profile"]').click()
        page.locator('[data-act="settings"]').click()
        page.locator('[data-act="privacy"]').click()
        page.locator('[data-act="importText"]').click()
        page.locator('#importTextArea').fill(json.dumps(snapshot,ensure_ascii=False))
        page.locator('[data-act="stageTextImport"]').click()
        page.locator('[data-act="confirmImport"]').click()
        assert isinstance(state(page).get('goalHistory'),list)
        page.locator('[data-act="plan"]').click()
        page.locator('#goalForm button[type="submit"]').click()
        assert len(state(page)['goalHistory'])==1
    finally:page.close()

TESTS=[test_launch_navigation,test_numerical_engine,test_date_picker_and_future,test_catalog_save_retro_persistence,test_future_planned_not_consumed,test_planned_does_not_count,test_delete_undo,test_manual_recipe_edit,test_historical_norms,test_progress_periods_missing,test_supplements,test_export_json,test_segments_and_layout,test_legacy_goalhistory_compatibility,test_text_backup_import_legacy]

if __name__=='__main__':
    with sync_playwright() as p:
        BROWSER=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
        try:
            for fn in TESTS:
                try:
                    fn();RESULTS.append({'name':fn.__name__,'status':'passed'})
                    print('PASS',fn.__name__,flush=True)
                except Exception as e:
                    RESULTS.append({'name':fn.__name__,'status':'failed','error':str(e),'traceback':traceback.format_exc(limit=4)})
                    print('FAIL',fn.__name__,repr(e),flush=True)
        finally:
            BROWSER.close()
    out=ROOT/'snapshot_qa_results.json'
    out.write_text(json.dumps({'total':len(TESTS),'passed':sum(x['status']=='passed' for x in RESULTS),'failed':sum(x['status']=='failed' for x in RESULTS),'results':RESULTS},ensure_ascii=False,indent=2))
    print('RESULT',sum(x['status']=='passed' for x in RESULTS),'/',len(TESTS),'->',out)
