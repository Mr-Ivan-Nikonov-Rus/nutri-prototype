"""Standalone NUTRI v19.3 Chromium QA without external network or npm.
Requires Python playwright and locally installed Chromium. Uses a fresh, isolated
about:blank page and in-memory localStorage shim for every scenario.
"""
from __future__ import annotations
import json, os, sys, traceback
from datetime import datetime, timedelta
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).parents[1]
HTML = (ROOT / 'index.html').read_text(encoding='utf-8')
RESULTS = []
SCREENSHOTS = ROOT / 'test-results' / 'local-screenshots'
SCREENSHOTS.mkdir(parents=True, exist_ok=True)
INIT_STORAGE = """(initial) => {
 const data = new Map(Object.entries(initial || {}));
 Object.defineProperty(window, 'localStorage', { configurable: true,
  value: { getItem(k){ return data.has(k) ? data.get(k) : null },
   setItem(k,v){ data.set(String(k),String(v)) },
   removeItem(k){ data.delete(String(k)) },
   clear(){ data.clear() } }
 });
}"""


def browser_today(page):
    return page.evaluate("""() => {const d=new Date(); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0')+'-'+String(d.getDate()).padStart(2,'0')}""")


def shift(day, delta):
    return (datetime.strptime(day, '%Y-%m-%d').date() + timedelta(days=delta)).isoformat()


def state(page):
    return page.evaluate('NUTRI_QA.getState()')


def tab(page, name):
    page.locator(f'[data-act="tab"][data-route="{name}"]').click()


def add_catalog(page, date=None, status='consumed', meal='breakfast'):
    if page.evaluate('NUTRI_QA.getRoute()') != 'nutrition':
        tab(page, 'nutrition')
    if date:
        page.locator('[data-change="diaryDate"]').fill(date)
    page.locator('[data-act="catalog"]').first.click()
    page.locator('[data-act="catalogType"][data-val="products"]').click()
    first_id = page.evaluate('NUTRI_QA.DB.ingredients.slice(0,100).find(x=>(4*x.p+9*x.f+4*x.c)>20)?.id')
    assert first_id
    page.locator(f'.catalog-card[data-type="product"][data-id="{first_id}"]').click()
    page.locator('#previewMeal').select_option(meal)
    if date:
        page.locator('#previewEntryDate').fill(date)
    page.locator(f'[data-act="savePreview"][data-status="{status}"]').click()


def new_page(browser, mobile=True, storage=None):
    context = browser.new_context(viewport={'width': 390 if mobile else 1280, 'height': 844 if mobile else 900},
                                  device_scale_factor=3 if mobile else 1, has_touch=mobile, is_mobile=mobile)
    page = context.new_page()
    exceptions=[]
    page.on('pageerror', lambda error: exceptions.append(str(error)))
    page.evaluate(INIT_STORAGE, storage or {})
    page.set_content(HTML, wait_until='domcontentloaded')
    assert page.evaluate('typeof window.NUTRI_QA === "object"')
    assert page.evaluate('window.NUTRI_QA.appVersion')=='19.3'
    return context, page, exceptions


def scenario(name):
    def deco(func):
        SCENARIOS.append((name,func))
        return func
    return deco

SCENARIOS=[]

@scenario('boot and built-in nutrition model')
def t_boot(page):
    s=state(page)
    assert not s['entries'] and not s['supplements']
    result=page.evaluate('''() => ({n:NUTRI_QA.DB.dims.length,weight:NUTRI_QA.DB.dims.reduce((a,x)=>a+x.weight,0),qa:NUTRI_QA.nutriBalanceSelfTests()})''')
    assert result['n']==22 and abs(result['weight']-1)<1e-10
    assert result['qa']['passed']==result['qa']['total'] and result['qa']['total']>0

@scenario('overview / nutrition / progress navigation')
def t_navigation(page):
    tab(page,'nutrition');assert page.evaluate('NUTRI_QA.getRoute()')=='nutrition'
    tab(page,'progress');assert page.evaluate('NUTRI_QA.getRoute()')=='progress'
    tab(page,'today');assert page.evaluate('NUTRI_QA.getRoute()')=='today'

@scenario('valid / invalid / future dates')
def t_valid_dates(page):
    future=shift(browser_today(page),1)
    v=page.evaluate('''f => {const t=NUTRI_QA.validDiaryDate;return [t('2024-02-29'),t('2024-02-30'),t('1899-12-31'),t('1900-01-01'),t(f),t(f,{allowFuture:true})]}''',future)
    assert v == [True,False,False,True,False,True]

@scenario('overview earlier date, forward button locked today')
def t_date_arrows(page):
    today=browser_today(page)
    page.locator('.today-datebar [data-act="day"][data-num="-1"]').click()
    assert page.evaluate('NUTRI_QA.getDate()')==shift(today,-1)
    page.locator('.today-datebar [data-act="day"][data-num="1"]').click()
    assert page.evaluate('NUTRI_QA.getDate()')==today
    assert page.locator('.today-datebar [data-act="day"][data-num="1"]').is_disabled()

@scenario('catalog product consumed on historical date')
def t_catalog_past(page):
    d=shift(browser_today(page),-2)
    add_catalog(page,date=d)
    s=state(page)
    assert len(s['entries'])==1 and s['entries'][0]['date']==d
    assert s['entries'][0]['status']=='consumed' and s['entries'][0]['meal']=='breakfast'
    assert page.evaluate('d=>NUTRI_QA.sumDay(d).kcal',d)>0

@scenario('future consumed prohibited, planned allowed')
def t_future(page):
    d=shift(browser_today(page),2)
    tab(page,'nutrition')
    page.locator('[data-act="catalog"]').first.click()
    page.locator('[data-act="catalogType"][data-val="products"]').click()
    page.locator('.catalog-card[data-type="product"]').first.click()
    page.locator('#previewEntryDate').fill(d)
    page.locator('[data-act="savePreview"][data-status="consumed"]').click()
    assert len(state(page)['entries'])==0
    assert 'будущую дату' in page.locator('#toast').inner_text()
    page.locator('[data-act="savePreview"][data-status="planned"]').click()
    s=state(page)
    assert len(s['entries'])==1 and s['entries'][0]['status']=='planned' and s['entries'][0]['date']==d
    assert page.evaluate('d=>NUTRI_QA.sumDay(d).kcal',d)==0

@scenario('historical date retained across tabs')
def t_date_tabs(page):
    d=shift(browser_today(page),-18)
    page.locator('[data-change="overviewDate"]').fill(d)
    assert page.evaluate('NUTRI_QA.getDate()')==d
    tab(page,'nutrition')
    assert page.locator('[data-change="diaryDate"]').input_value()==d
    tab(page,'progress')
    assert page.locator('[data-change="progressEndDate"]').input_value()==d

@scenario('planned-only entries not counted as food')
def t_planned_not_factual(page):
    d=shift(browser_today(page),-3)
    add_catalog(page,date=d,status='planned')
    assert page.evaluate('d=>NUTRI_QA.sumDay(d).kcal',d)==0
    obs=page.evaluate('d=>NUTRI_QA.progressObservation("kcal",d)',d)
    assert obs['v'] is None

@scenario('retrospective entry flows to progress chart')
def t_progress(page):
    d=shift(browser_today(page),-4)
    add_catalog(page,date=d)
    energy=page.evaluate('d=>NUTRI_QA.sumDay(d).kcal',d)
    obs=page.evaluate('d=>NUTRI_QA.progressObservation("kcal",d)',d)
    assert abs(obs['v']-energy)<1e-5
    tab(page,'progress')
    page.locator('[data-change="progressEndDate"]').fill(d)
    for days in ['7','28','90','0']:
        page.locator(f'[data-act="period"][data-num="{days}"]').click()
        assert page.locator('svg.progress-plot').count()==1
    assert 'Ошибка интерфейса' not in page.locator('#main').inner_text()

@scenario('delete entry, undo restores exact same entry')
def t_undo(page):
    d=shift(browser_today(page),-2)
    add_catalog(page,date=d)
    item=state(page)['entries'][0]
    page.locator('[data-act="meal"][data-meal="breakfast"]').click()
    page.locator(f'[data-act="deleteEntry"][data-id="{item["id"]}"]').click()
    assert not state(page)['entries']
    page.locator('[data-act="undoDelete"]').click()
    assert len(state(page)['entries'])==1 and state(page)['entries'][0]['id']==item['id']

@scenario('manual ingredient recipe creation and edit')
def t_manual(page):
    d=shift(browser_today(page),-3)
    tab(page,'nutrition')
    page.locator('[data-act="addMeal"]').first.click()
    page.locator('#manualEntryDate').fill(d)
    page.locator('#manualName').fill('QA домашний обед')
    name=page.evaluate('NUTRI_QA.DB.ingredients.find(x=>x.name.length>3 && 4*x.p+9*x.f+4*x.c>20).name')
    page.locator('[data-manual="search"][data-index="0"]').fill(name)
    page.locator('.ingredient-choice[data-index="0"]').first.click()
    page.locator('[data-manual="grams"][data-index="0"]').fill('150')
    page.locator('input[data-manual="saveRecipe"]').check()
    page.locator('#manualMealForm button[type="submit"]').click()
    s=state(page)
    assert len(s['entries'])==1 and len(s['userRecipes'])==1
    assert s['entries'][0]['date']==d and s['entries'][0]['items'][0]['g']==150
    assert s['entries'][0]['kind']=='manual'
    item_id=s['entries'][0]['id']
    page.locator('[data-act="meal"][data-meal="lunch"]').click()
    page.locator(f'[data-act="editEntry"][data-id="{item_id}"]').click()
    page.locator('[data-manual="grams"][data-index="0"]').fill('180')
    page.locator('#manualMealForm button[type="submit"]').click()
    s=state(page)
    assert len(s['entries'])==1 and s['entries'][0]['items'][0]['g']==180

@scenario('supplements planned to taken, without food calories')
def t_supplement(page):
    tab(page,'nutrition')
    page.locator('[data-act="supplementForm"]').first.click()
    page.locator('#suppForm [name="name"]').fill('QA D3')
    page.locator('#suppForm [name="amount"]').fill('10')
    page.locator('#suppForm [name="nutrient"]').select_option('vitamin_d_mcg')
    page.locator('#suppForm [name="nutrientAmount"]').fill('10')
    page.locator('#suppForm button[type="submit"]').click()
    assert state(page)['supplements'][0]['status']=='planned'
    if page.evaluate('NUTRI_QA.getRoute()')!='nutrition':tab(page,'nutrition')
    page.locator('[data-act="toggleSupp"]').first.click()
    assert state(page)['supplements'][0]['status']=='taken'
    assert page.evaluate('NUTRI_QA.sumDay().kcal')==0

@scenario('export JSON consistent with actual diary')
def t_backup(page):
    d=shift(browser_today(page),-2)
    add_catalog(page,date=d)
    page.locator('[data-act="profile"]').click()
    page.locator('[data-act="settings"]').click()
    page.locator('[data-act="privacy"]').click()
    page.locator('[data-act="export"]').click()
    snapshot=json.loads(page.locator('#backupTextArea').input_value())
    assert snapshot['schemaVersion']==1 and len(snapshot['entries'])==1
    assert snapshot['entries'][0]['date']==d

@scenario('overview nutrients and five vitamin/mineral categories')
def t_micro_sections(page):
    assert page.locator('[data-act="segment"]').count()==3
    assert 'Клетчатка' in page.locator('#main').inner_text()
    page.locator('[data-act="segment"][data-val="vitamins"]').click()
    assert 'Витамин D' in page.locator('#main').inner_text()
    page.locator('[data-act="segment"][data-val="minerals"]').click()
    assert 'Магний' in page.locator('#main').inner_text()
    page.locator('[data-act="segment"][data-val="macros"]').click()
    assert 'Насыщенные' in page.locator('#main').inner_text()

@scenario('historical reference uses actual age at chosen date')
def t_age(page):
    assert page.evaluate('''() => ['2026-12-14','2026-12-15','2026-12-16'].map(d=>NUTRI_QA.ageFromBirthOnDate('2000-12-15',d))''')==[25,26,26]

@scenario('reference timeline toggle uses saved goal history')
def t_historical_goals(page):
    s=state(page)
    old={**s['goals'],'kcal':1700}
    s['goalHistory']=[dict(date='2026-01-01',at='2026-01-01T09:00:00.000Z',next=old,previous=old,reason='QA')]
    # App reload simulated by fresh DOM + its localStorage shim seeded with QA fixture.
    # Cannot redeclare global consts in a single document, hence separate browser context.
    return json.dumps(s,ensure_ascii=False)

@scenario('browser widths mobile and desktop without horizontal scrolling')
def t_layout(page):
    b=page.evaluate('''() => ({viewport:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,phone:document.querySelector('#phone').getBoundingClientRect().width})''')
    assert b['scroll'] <= b['viewport']+1, b
    assert b['phone'] <= b['viewport']+1, b

@scenario('local-first: no outgoing network activity from app')
def t_offline(page):
    # Source HTML has embedded logo and scripts; no external URLs should be requested.
    requests=[]
    page.on('request',lambda q:requests.append(q.url))
    tab(page,'nutrition')
    page.locator('[data-act="catalog"]').first.click()
    tab_active=page.evaluate('NUTRI_QA.getRoute()')=='catalog'
    assert tab_active and requests==[],requests

@scenario('manual mode remains manual after profile update')
def t_profile(page):
    page.locator('[data-act="profile"]').click()
    page.locator('[data-act="about"]').click()
    page.locator('#aboutForm [name="name"]').fill('QA')
    page.locator('#aboutForm [name="birth"]').fill('1990-04-10')
    page.locator('#aboutForm [name="sex"]').select_option('male')
    page.locator('#aboutForm [name="height"]').fill('180')
    page.locator('#aboutForm [name="weight"]').fill('80')
    # Changing physiology proposes automatic calculation; explicit opt-out must be honored.
    page.locator('#aboutForm [name="autoPlanAfterWeight"]').uncheck()
    page.locator('#aboutForm button[type="submit"]').click()
    assert state(page)['profile']['name']=='QA'
    assert state(page)['goals']['mode']=='manual'


def main():
    report={'source':'NUTRI v19.3 exact indexed source; local set_content in Chromium','time':datetime.utcnow().isoformat()+'Z','tests':[]}
    viewports=sys.argv[1:] or ['mobile','desktop']
    assert all(v in ('mobile','desktop') for v in viewports), viewports
    with sync_playwright() as p:
        browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
        for viewport in viewports:
            for name,func in SCENARIOS:
                context=None
                try:
                    context,page,errors = new_page(browser,mobile=viewport=='mobile')
                    data=func(page)
                    if name=='reference timeline toggle uses saved goal history':
                        context2,page2,e2=new_page(browser,mobile=viewport=='mobile',storage={'NUTRI_PERSONAL_V1':data})
                        assert page2.evaluate('NUTRI_QA.goalsForDate("2026-02-01").kcal')==2000
                        tab(page2,'progress')
                        page2.locator('[data-change="normTimeline"]').select_option('historical')
                        assert page2.evaluate('NUTRI_QA.goalsForDate("2026-02-01").kcal')==1700
                        assert e2==[],e2
                        context2.close()
                    if errors:
                        raise AssertionError('JavaScript errors: '+repr(errors))
                    status='PASS';detail=''
                except Exception as exc:
                    status='FAIL';detail=str(exc)[:1200]
                    if context:
                        try:page.screenshot(path=str(SCREENSHOTS/f'{viewport}_{len(report["tests"]):02d}.png'),full_page=True)
                        except Exception:pass
                    print('TRACE',traceback.format_exc()[-2200:],flush=True)
                finally:
                    if context:context.close()
                report['tests'].append({'viewport':viewport,'name':name,'status':status,'detail':detail})
                print(f'{status:4} [{viewport:7}] {name}',flush=True)
        browser.close()
    dst=ROOT/'test-results'/('local_qa_'+('_'.join(viewports))+'_report.json')
    dst.parent.mkdir(parents=True,exist_ok=True)
    dst.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    nfail=sum(r['status']=='FAIL' for r in report['tests'])
    print(f'RESULT: {len(report["tests"])-nfail}/{len(report["tests"])} PASSED; failures: {nfail}; report={dst}')
    return 1 if nfail else 0

if __name__=='__main__':
    sys.exit(main())
